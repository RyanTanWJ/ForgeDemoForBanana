﻿using UnityEngine;

public class Primitive : MonoBehaviour
{
	/// <summary>
	/// Used to determine if this object can be destroyed
	/// </summary>
	public bool readOnly = false;
}