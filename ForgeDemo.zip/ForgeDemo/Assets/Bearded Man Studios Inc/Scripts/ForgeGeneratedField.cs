﻿using System;

namespace BeardedManStudios.Forge.Networking.Generated
{
	[AttributeUsage(AttributeTargets.Field)]
	public class ForgeGeneratedFieldAttribute : System.Attribute
	{
		public ForgeGeneratedFieldAttribute()
		{
		}
	}
}
