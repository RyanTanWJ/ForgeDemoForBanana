﻿namespace BeardedManStudios.Forge.Networking.UnityEditor.Serializer
{
	/// <summary>
	/// Indication that this class is serializable
	/// </summary>
	public interface IFNSerializable
	{
	}
}
